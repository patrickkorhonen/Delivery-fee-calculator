First run the command 'npm install'


The app can be run in development mode by using the command 'npm start'


You can find tests at App.test.tsx
They can be run by using the command 'npm test'